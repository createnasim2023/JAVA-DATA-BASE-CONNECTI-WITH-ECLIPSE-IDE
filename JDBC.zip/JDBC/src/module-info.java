/**
 * 
 */
/**
 * @author SALIM ALI
 *
 */
module JDBC {
	requires java.sql;
}